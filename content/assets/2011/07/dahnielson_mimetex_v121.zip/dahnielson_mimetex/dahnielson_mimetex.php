<?php
/*
Plugin Name: mimeTeX
Plugin URI: http://en.dahnielson.com/2006/09/mimetex-plugin.html
Description: Use &lt;tex bg="000000~ffffff" fg="000000~ffffff" sz="-4~4" escaped="true|false"&gt;&lt;/tex&gt; tags to embed LaTeX math in posts.
Version: 1.2.1
Author: Anders Dahnielson; Modified by calf (April 12, 2009)
Author URI: http://dahnielson.com
*/

/*  Copyright 2006-2007  Anders Dahnielson (email : anders@dahnielson.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

class dahnielson_mimetex
{
	function parse($content)
	{
		$regex = '#<tex(?:\s|bg=["\']([\w]+)["\']|fg=["\']([\w]+)["\']|'.
			'sz=["\']([0-9+-]+)["\']|escaped=["\'](true|false)?["\'])*>(.*?)</tex>#si';
		return preg_replace_callback($regex, array(&$this, 'replace_tex'), $content);
	}

	function replace_tex($match)
	{
		$formula_bg = $match[1];
		if (!$formula_bg) $formula_bg = 'ffffff';
		$formula_fg = $match[2];
		if (!$formula_fg) $formula_fg = '000000';
		$formula_sz = $match[3];
		if (!$formula_sz) $formula_sz = '0';
		$escaped = $match[4];
		$formula_text = $match[5];
		if ($escaped == 'true') $formula_text = htmlspecialchars_decode($formula_text); 
		$formula_text_html = htmlspecialchars($formula_text);
		$formula_hash = md5($formula_text.'_'.$formula_bg.'_'.$formula_fg.'_'.$formula_sz.'_1.2.1');
		$formula_filename = 'tex_'.$formula_hash.'.png';

		$cache_path = ABSPATH . '/wp-content/cache/';
		$cache_formula_path = $cache_path . $formula_filename;
		$cache_url = get_bloginfo('wpurl') . '/wp-content/cache/';
		$cache_formula_url = $cache_url . $formula_filename;
		
 		if (!is_file($cache_formula_path))
 		{
			$req_url = 'http://l.wordpress.com/latex.php?latex='.urlencode($formula_text).
				'&bg='.urlencode($formula_bg).'&fg='.urlencode($formula_fg).'&s='.urlencode($formula_sz);
			$mimetex_host = curl_init($req_url);
			$cache_file = fopen($cache_formula_path, 'w');
			curl_setopt($mimetex_host, CURLOPT_FILE, $cache_file);
			curl_setopt($mimetex_host, CURLOPT_HEADER, 0);
			curl_exec($mimetex_host);
			curl_close($mimetex_host);
			fclose($cache_file);
 		}
		
		return "<img class=\"mimetex\" src=\"$cache_formula_url\" alt=\"$formula_text_html\" title=\"$formula_text_html\" />";
	}
}

$dahnielson_mimetex_object = new dahnielson_mimetex;
add_filter('the_title', array($dahnielson_mimetex_object, 'parse'), 1);
add_filter('the_content', array($dahnielson_mimetex_object, 'parse'), 1);
add_filter('the_excerpt', array($dahnielson_mimetex_object, 'parse'), 1);

?>
